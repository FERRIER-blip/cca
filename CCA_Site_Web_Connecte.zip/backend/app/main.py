from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from app.db.database import engine, Base
from app.core.config import settings

# Import routers
from app.api import auth, services, trainings, testimonials, experts, partners, news, contact, admin

# Create database tables
Base.metadata.create_all(bind=engine)

# Create uploads directory
os.makedirs("uploads", exist_ok=True)

app = FastAPI(
    title=settings.APP_NAME,
    description="API pour le Cabinet Construire l'Avenir (CCA)",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files for uploads
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Include routers
app.include_router(auth.router, prefix="/api")
app.include_router(services.router, prefix="/api")
app.include_router(trainings.router, prefix="/api")
app.include_router(testimonials.router, prefix="/api")
app.include_router(experts.router, prefix="/api")
app.include_router(partners.router, prefix="/api")
app.include_router(news.router, prefix="/api")
app.include_router(contact.router, prefix="/api")
app.include_router(admin.router, prefix="/api")


@app.get("/")
def root():
    return {
        "message": "Bienvenue sur l'API du Cabinet Construire l'Avenir (CCA)",
        "version": "1.0.0",
        "docs": "/docs"
    }


@app.get("/api/health")
def health_check():
    return {"status": "healthy"}
