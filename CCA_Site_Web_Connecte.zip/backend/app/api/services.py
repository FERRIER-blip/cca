from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.models.models import Service
from app.schemas.schemas import ServiceCreate, ServiceUpdate, Service
from app.api.auth import get_current_admin

router = APIRouter(prefix="/services", tags=["Services"])


@router.get("/", response_model=List[Service])
def get_services(db: Session = Depends(get_db)):
    services = db.query(Service).filter(Service.is_active == True).order_by(Service.order).all()
    return services


@router.get("/all", response_model=List[Service])
def get_all_services(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    services = db.query(Service).order_by(Service.order).all()
    return services


@router.get("/{slug}", response_model=Service)
def get_service_by_slug(slug: str, db: Session = Depends(get_db)):
    service = db.query(Service).filter(Service.slug == slug).first()
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    return service


@router.post("/", response_model=Service)
def create_service(
    service_data: ServiceCreate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    # Check if slug exists
    existing = db.query(Service).filter(Service.slug == service_data.slug).first()
    if existing:
        raise HTTPException(status_code=400, detail="Slug already exists")
    
    db_service = Service(**service_data.dict())
    db.add(db_service)
    db.commit()
    db.refresh(db_service)
    return db_service


@router.put("/{service_id}", response_model=Service)
def update_service(
    service_id: int,
    service_data: ServiceUpdate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    service = db.query(Service).filter(Service.id == service_id).first()
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    update_data = service_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(service, field, value)
    
    db.commit()
    db.refresh(service)
    return service


@router.delete("/{service_id}")
def delete_service(
    service_id: int,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    service = db.query(Service).filter(Service.id == service_id).first()
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    db.delete(service)
    db.commit()
    return {"message": "Service deleted successfully"}
