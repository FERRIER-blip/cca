from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.models.models import ContactMessage, ServiceRequest
from app.schemas.schemas import ContactMessageCreate, ContactMessage, ServiceRequestCreate, ServiceRequest
from app.api.auth import get_current_user, get_current_admin

router = APIRouter(prefix="/contact", tags=["Contact"])


@router.post("/message", response_model=ContactMessage)
def send_message(
    message_data: ContactMessageCreate,
    db: Session = Depends(get_db)
):
    db_message = ContactMessage(**message_data.dict())
    db.add(db_message)
    db.commit()
    db.refresh(db_message)
    return db_message


@router.get("/messages", response_model=List[ContactMessage])
def get_messages(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    messages = db.query(ContactMessage).order_by(ContactMessage.created_at.desc()).all()
    return messages


@router.post("/service-request", response_model=ServiceRequest)
def create_service_request(
    request_data: ServiceRequestCreate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    db_request = ServiceRequest(
        **request_data.dict(),
        user_id=current_user.id
    )
    db.add(db_request)
    db.commit()
    db.refresh(db_request)
    return db_request


@router.get("/service-requests", response_model=List[ServiceRequest])
def get_service_requests(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    requests = db.query(ServiceRequest).order_by(ServiceRequest.created_at.desc()).all()
    return requests


@router.put("/service-requests/{request_id}")
def update_service_request(
    request_id: int,
    status: str,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    request = db.query(ServiceRequest).filter(ServiceRequest.id == request_id).first()
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    
    request.status = status
    db.commit()
    db.refresh(request)
    return request
