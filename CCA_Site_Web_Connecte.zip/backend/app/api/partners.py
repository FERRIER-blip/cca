from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.models.models import Partner
from app.schemas.schemas import PartnerCreate, PartnerUpdate, Partner
from app.api.auth import get_current_admin

router = APIRouter(prefix="/partners", tags=["Partners"])


@router.get("/", response_model=List[Partner])
def get_partners(db: Session = Depends(get_db)):
    partners = db.query(Partner).filter(Partner.is_active == True).order_by(Partner.order).all()
    return partners


@router.get("/all", response_model=List[Partner])
def get_all_partners(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    partners = db.query(Partner).order_by(Partner.order).all()
    return partners


@router.post("/", response_model=Partner)
def create_partner(
    partner_data: PartnerCreate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_partner = Partner(**partner_data.dict())
    db.add(db_partner)
    db.commit()
    db.refresh(db_partner)
    return db_partner


@router.put("/{partner_id}", response_model=Partner)
def update_partner(
    partner_id: int,
    partner_data: PartnerUpdate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    partner = db.query(Partner).filter(Partner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    
    update_data = partner_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(partner, field, value)
    
    db.commit()
    db.refresh(partner)
    return partner


@router.delete("/{partner_id}")
def delete_partner(
    partner_id: int,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    partner = db.query(Partner).filter(Partner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    
    db.delete(partner)
    db.commit()
    return {"message": "Partner deleted successfully"}
