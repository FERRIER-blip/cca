from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from app.db.database import get_db
from app.models.models import (
    User, Expert, Service, Training, Testimonial, Partner, 
    News, ServiceRequest, Enrollment, ContactMessage
)
from app.schemas.schemas import DashboardStats, User
from app.api.auth import get_current_admin

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/dashboard", response_model=DashboardStats)
def get_dashboard_stats(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    stats = DashboardStats(
        total_users=db.query(User).count(),
        total_trainings=db.query(Training).count(),
        total_services=db.query(Service).count(),
        total_testimonials=db.query(Testimonial).count(),
        total_partners=db.query(Partner).count(),
        pending_requests=db.query(ServiceRequest).filter(ServiceRequest.status == "new").count(),
        recent_enrollments=db.query(Enrollment).filter(
            Enrollment.enrolled_at >= func.date('now', '-30 days')
        ).count()
    )
    return stats


@router.get("/users", response_model=List[User])
def get_all_users(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return users


@router.put("/users/{user_id}/toggle-admin")
def toggle_user_admin(
    user_id: int,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.is_admin = not user.is_admin
    db.commit()
    db.refresh(user)
    return {"message": f"User admin status updated to {user.is_admin}"}


@router.delete("/users/{user_id}")
def delete_user(
    user_id: int,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db.delete(user)
    db.commit()
    return {"message": "User deleted successfully"}


@router.get("/recent-activities")
def get_recent_activities(
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db),
    limit: int = 10
):
    activities = []
    
    # Recent users
    recent_users = db.query(User).order_by(User.created_at.desc()).limit(5).all()
    for user in recent_users:
        activities.append({
            "type": "user_registered",
            "description": f"New user registered: {user.first_name} {user.last_name}",
            "date": user.created_at
        })
    
    # Recent enrollments
    recent_enrollments = db.query(Enrollment).order_by(Enrollment.enrolled_at.desc()).limit(5).all()
    for enrollment in recent_enrollments:
        activities.append({
            "type": "enrollment",
            "description": f"New enrollment in {enrollment.training.title}",
            "date": enrollment.enrolled_at
        })
    
    # Recent service requests
    recent_requests = db.query(ServiceRequest).order_by(ServiceRequest.created_at.desc()).limit(5).all()
    for request in recent_requests:
        activities.append({
            "type": "service_request",
            "description": f"New service request from {request.contact_name}",
            "date": request.created_at
        })
    
    # Sort by date
    activities.sort(key=lambda x: x["date"], reverse=True)
    return activities[:limit]
