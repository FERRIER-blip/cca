from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.models.models import Testimonial
from app.schemas.schemas import TestimonialCreate, TestimonialUpdate, Testimonial
from app.api.auth import get_current_user, get_current_admin

router = APIRouter(prefix="/testimonials", tags=["Testimonials"])


@router.get("/", response_model=List[Testimonial])
def get_testimonials(db: Session = Depends(get_db)):
    testimonials = db.query(Testimonial).filter(
        Testimonial.is_approved == True
    ).order_by(Testimonial.created_at.desc()).all()
    return testimonials


@router.get("/featured", response_model=List[Testimonial])
def get_featured_testimonials(db: Session = Depends(get_db)):
    testimonials = db.query(Testimonial).filter(
        Testimonial.is_approved == True,
        Testimonial.is_featured == True
    ).all()
    return testimonials


@router.get("/all", response_model=List[Testimonial])
def get_all_testimonials(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    testimonials = db.query(Testimonial).order_by(Testimonial.created_at.desc()).all()
    return testimonials


@router.post("/", response_model=Testimonial)
def create_testimonial(
    testimonial_data: TestimonialCreate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    db_testimonial = Testimonial(
        **testimonial_data.dict(),
        user_id=current_user.id,
        is_approved=False  # Requires admin approval
    )
    db.add(db_testimonial)
    db.commit()
    db.refresh(db_testimonial)
    return db_testimonial


@router.put("/{testimonial_id}", response_model=Testimonial)
def update_testimonial(
    testimonial_id: int,
    testimonial_data: TestimonialUpdate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    testimonial = db.query(Testimonial).filter(Testimonial.id == testimonial_id).first()
    if not testimonial:
        raise HTTPException(status_code=404, detail="Testimonial not found")
    
    update_data = testimonial_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(testimonial, field, value)
    
    db.commit()
    db.refresh(testimonial)
    return testimonial


@router.delete("/{testimonial_id}")
def delete_testimonial(
    testimonial_id: int,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    testimonial = db.query(Testimonial).filter(Testimonial.id == testimonial_id).first()
    if not testimonial:
        raise HTTPException(status_code=404, detail="Testimonial not found")
    
    db.delete(testimonial)
    db.commit()
    return {"message": "Testimonial deleted successfully"}
