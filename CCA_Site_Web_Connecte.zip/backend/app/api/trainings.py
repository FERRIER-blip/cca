from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.models.models import Training, Enrollment
from app.schemas.schemas import TrainingCreate, TrainingUpdate, Training, EnrollmentCreate, Enrollment
from app.api.auth import get_current_user, get_current_admin

router = APIRouter(prefix="/trainings", tags=["Trainings"])


@router.get("/", response_model=List[Training])
def get_trainings(db: Session = Depends(get_db)):
    return db.query(Training).filter(Training.is_active == True).all()


@router.get("/all", response_model=List[Training])
def get_all_trainings(admin=Depends(get_current_admin), db: Session = Depends(get_db)):
    return db.query(Training).all()


# ⚠️ Ces routes DOIVENT être avant /{slug} pour éviter le conflit
@router.post("/enroll", response_model=Enrollment)
def enroll_in_training(
    enrollment_data: EnrollmentCreate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    existing = db.query(Enrollment).filter(
        Enrollment.user_id == current_user.id,
        Enrollment.training_id == enrollment_data.training_id
    ).first()

    if existing:
        raise HTTPException(status_code=400, detail="Déjà inscrit à cette formation")

    enrollment = Enrollment(
        user_id=current_user.id,
        training_id=enrollment_data.training_id,
        status="pending",
        progress=0
    )
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return enrollment


@router.get("/my/enrollments", response_model=List[Enrollment])
def get_my_enrollments(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Enrollment).filter(Enrollment.user_id == current_user.id).all()


@router.get("/{slug}", response_model=Training)
def get_training_by_slug(slug: str, db: Session = Depends(get_db)):
    training = db.query(Training).filter(Training.slug == slug).first()
    if not training:
        raise HTTPException(status_code=404, detail="Formation introuvable")
    return training


@router.post("/", response_model=Training)
def create_training(
    training_data: TrainingCreate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    existing = db.query(Training).filter(Training.slug == training_data.slug).first()
    if existing:
        raise HTTPException(status_code=400, detail="Slug déjà utilisé")
    db_training = Training(**training_data.dict())
    db.add(db_training)
    db.commit()
    db.refresh(db_training)
    return db_training


@router.put("/{training_id}", response_model=Training)
def update_training(
    training_id: int,
    training_data: TrainingUpdate,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    training = db.query(Training).filter(Training.id == training_id).first()
    if not training:
        raise HTTPException(status_code=404, detail="Formation introuvable")
    for field, value in training_data.dict(exclude_unset=True).items():
        setattr(training, field, value)
    db.commit()
    db.refresh(training)
    return training


@router.delete("/{training_id}")
def delete_training(
    training_id: int,
    admin=Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    training = db.query(Training).filter(Training.id == training_id).first()
    if not training:
        raise HTTPException(status_code=404, detail="Formation introuvable")
    db.delete(training)
    db.commit()
    return {"message": "Formation supprimée avec succès"}
