import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { GraduationCap, User, Loader2, BookOpen, Clock } from 'lucide-react';
import { trainingsAPI } from '@/services/api';
import { useAuthStore } from '@/store/authStore';
import type { Enrollment } from '@/types';

export default function ClientDashboard() {
  const { user } = useAuthStore();

  const { data: enrollments, isLoading } = useQuery<Enrollment[]>({
    queryKey: ['my-enrollments'],
    queryFn: async () => (await trainingsAPI.getMyEnrollments()).data,
  });

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-700',
    active: 'bg-blue-100 text-blue-700',
    completed: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700',
  };
  const statusLabels: Record<string, string> = {
    pending: 'En attente', active: 'En cours', completed: 'Terminé', cancelled: 'Annulé',
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a237e]">Bonjour, {user?.first_name} !</h1>
          <p className="text-gray-600 mt-1">Bienvenue sur votre espace personnel.</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {[
            { label: 'Formations inscrites', value: enrollments?.length || 0, icon: GraduationCap, color: '#1a237e' },
            { label: 'En cours', value: enrollments?.filter(e => e.status === 'active').length || 0, icon: BookOpen, color: '#ff6f00' },
            { label: 'Terminées', value: enrollments?.filter(e => e.status === 'completed').length || 0, icon: Clock, color: '#4fc3f7' },
          ].map(stat => (
            <div key={stat.label} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{stat.label}</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: stat.color }}>{stat.value}</p>
                </div>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${stat.color}15` }}>
                  <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-[#1a237e]">Mes formations</h2>
            <Link to="/formations" className="text-[#ff6f00] text-sm font-medium hover:underline">Voir toutes →</Link>
          </div>
          {isLoading && <div className="flex justify-center py-6"><Loader2 className="w-6 h-6 text-[#1a237e] animate-spin" /></div>}
          {enrollments && enrollments.length > 0 ? (
            <div className="space-y-3">
              {enrollments.map(enrollment => (
                <div key={enrollment.id} className="flex items-center justify-between p-4 rounded-xl bg-gray-50">
                  <div>
                    <p className="font-medium text-gray-800">{enrollment.training.title}</p>
                    <p className="text-sm text-gray-500">{enrollment.training.duration}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[enrollment.status]}`}>
                    {statusLabels[enrollment.status]}
                  </span>
                </div>
              ))}
            </div>
          ) : !isLoading ? (
            <div className="text-center py-8">
              <GraduationCap className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 mb-4">Vous n'êtes inscrit à aucune formation.</p>
              <Link to="/formations" className="bg-[#1a237e] text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-[#0d1245] transition-colors">Parcourir les formations</Link>
            </div>
          ) : null}
        </div>

        <div className="flex gap-4">
          <Link to="/client/profil" className="flex items-center gap-2 bg-white border border-gray-200 text-[#1a237e] px-4 py-3 rounded-xl font-medium hover:shadow-md transition-shadow">
            <User className="w-4 h-4" />Mon profil
          </Link>
          <Link to="/contact" className="flex items-center gap-2 bg-[#ff6f00] text-white px-4 py-3 rounded-xl font-medium hover:bg-[#e65100] transition-colors">
            Demander un service
          </Link>
        </div>
      </div>
    </div>
  );
}
