import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Mail, Loader2 } from 'lucide-react';
import { contactAPI } from '@/services/api';
import type { ContactMessage } from '@/types';

export default function AdminMessages() {
  const { data: messages, isLoading } = useQuery<ContactMessage[]>({
    queryKey: ['admin-messages'],
    queryFn: async () => (await contactAPI.getMessages()).data,
  });

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-[#1a237e]">Messages</h1>
        <p className="text-gray-600 mt-1">Messages reçus via le formulaire de contact</p>
      </motion.div>

      {isLoading && <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 text-[#1a237e] animate-spin" /></div>}

      {messages && messages.length > 0 ? (
        <div className="space-y-4">
          {messages.map(msg => (
            <motion.div key={msg.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`bg-white rounded-2xl p-6 shadow-sm border ${msg.is_read ? 'border-gray-100' : 'border-[#1a237e]/30 bg-blue-50/30'}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#1a237e]/10 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-[#1a237e]" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{msg.name}</p>
                    <p className="text-sm text-gray-500">{msg.email} {msg.phone && `· ${msg.phone}`}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {!msg.is_read && <span className="w-2 h-2 rounded-full bg-[#1a237e]" />}
                  <span className="text-xs text-gray-400">{new Date(msg.created_at).toLocaleString('fr-FR')}</span>
                </div>
              </div>
              <p className="font-medium text-gray-800 mb-1">{msg.subject}</p>
              <p className="text-gray-600 text-sm">{msg.message}</p>
            </motion.div>
          ))}
        </div>
      ) : !isLoading ? (
        <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-gray-100">
          <Mail className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Aucun message reçu pour le moment.</p>
        </div>
      ) : null}
    </div>
  );
}
