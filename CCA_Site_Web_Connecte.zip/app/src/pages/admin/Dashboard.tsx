import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Users, Briefcase, GraduationCap, Star, Building2, FileText, Loader2, Clock } from 'lucide-react';
import { adminAPI } from '@/services/api';
import type { DashboardStats } from '@/types';

const statConfig = [
  { key: 'total_users', label: 'Utilisateurs', icon: Users, color: '#1a237e', href: '/admin/utilisateurs' },
  { key: 'total_services', label: 'Services', icon: Briefcase, color: '#ff6f00', href: '/admin/services' },
  { key: 'total_trainings', label: 'Formations', icon: GraduationCap, color: '#4fc3f7', href: '/admin/formations' },
  { key: 'total_testimonials', label: 'Témoignages', icon: Star, color: '#1a237e', href: '/admin/temoignages' },
  { key: 'total_partners', label: 'Partenaires', icon: Building2, color: '#ff6f00', href: '/admin/partenaires' },
  { key: 'pending_requests', label: 'Demandes en attente', icon: FileText, color: '#4fc3f7', href: '/admin/demandes' },
] as const;

export default function AdminDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['admin-stats'],
    queryFn: async () => (await adminAPI.getDashboardStats()).data,
  });

  const { data: activities, isLoading: activitiesLoading } = useQuery<any[]>({
    queryKey: ['admin-activities'],
    queryFn: async () => (await adminAPI.getRecentActivities()).data,
  });

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h1 className="text-3xl font-bold text-[#1a237e]">Tableau de bord</h1>
        <p className="text-gray-600 mt-2">Vue d'ensemble de votre activité</p>
      </motion.div>

      {statsLoading && <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 text-[#1a237e] animate-spin" /></div>}

      {stats && (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {statConfig.map((sc, index) => (
            <motion.div key={sc.key} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }}>
              <Link to={sc.href}>
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${sc.color}15` }}>
                      <sc.icon className="w-6 h-6" style={{ color: sc.color }} />
                    </div>
                    <span className="text-3xl font-bold" style={{ color: sc.color }}>{stats[sc.key]}</span>
                  </div>
                  <p className="text-gray-600 font-medium">{sc.label}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.4 }} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-[#1a237e] mb-6">Activités récentes</h2>
        {activitiesLoading && <div className="flex justify-center py-4"><Loader2 className="w-6 h-6 text-[#1a237e] animate-spin" /></div>}
        {activities && activities.length > 0 ? (
          <div className="space-y-4">
            {activities.map((activity, index) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-xl bg-gray-50">
                <div className="w-8 h-8 rounded-full bg-[#1a237e]/10 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-[#1a237e]" />
                </div>
                <div>
                  <p className="text-gray-700 text-sm">{activity.description}</p>
                  <p className="text-gray-400 text-xs mt-1">{new Date(activity.date).toLocaleString('fr-FR')}</p>
                </div>
              </div>
            ))}
          </div>
        ) : !activitiesLoading ? (
          <p className="text-gray-500 text-center py-4">Aucune activité récente.</p>
        ) : null}
      </motion.div>
    </div>
  );
}
