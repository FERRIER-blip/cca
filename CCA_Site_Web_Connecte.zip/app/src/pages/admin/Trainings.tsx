import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Search, Trash2, Edit2, Loader2 } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { trainingsAPI } from '@/services/api';
import type { Training } from '@/types';

export default function AdminTrainings() {
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  const { data: trainings, isLoading } = useQuery<Training[]>({
    queryKey: ['admin-trainings'],
    queryFn: async () => (await trainingsAPI.getAll()).data,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => trainingsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-trainings'] });
      toast.success('Formation supprimée avec succès');
    },
    onError: () => toast.error('Erreur lors de la suppression'),
  });

  const filtered = trainings?.filter(t => t.title.toLowerCase().includes(searchQuery.toLowerCase())) || [];

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a237e]">Formations</h1>
          <p className="text-gray-600 mt-1">Gestion des formations</p>
        </div>
        <Button className="bg-[#1a237e] hover:bg-[#0d1245] text-white"><Plus className="w-4 h-4 mr-2" />Ajouter</Button>
      </motion.div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input placeholder="Rechercher..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10" />
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 text-[#1a237e] animate-spin" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Titre</TableHead>
                <TableHead>Durée</TableHead>
                <TableHead>Prix</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(training => (
                <TableRow key={training.id}>
                  <TableCell className="font-medium">{training.title}</TableCell>
                  <TableCell className="text-gray-500">{training.duration || '—'}</TableCell>
                  <TableCell className="text-gray-500">{training.price ? `${training.price.toLocaleString()} FCFA` : '—'}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${training.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                      {training.is_active ? 'Actif' : 'Inactif'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline"><Edit2 className="w-3 h-3" /></Button>
                      <Button size="sm" variant="outline" className="text-red-500 hover:text-red-700" onClick={() => deleteMutation.mutate(training.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        {!isLoading && filtered.length === 0 && <p className="text-center text-gray-500 py-8">Aucune formation trouvée.</p>}
      </div>
    </div>
  );
}
