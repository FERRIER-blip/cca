import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Search, Trash2, Edit2, Loader2, User } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { expertsAPI } from '@/services/api';
import type { Expert } from '@/types';

export default function AdminExperts() {
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  const { data: experts, isLoading } = useQuery<Expert[]>({
    queryKey: ['admin-experts'],
    queryFn: async () => (await expertsAPI.getAll()).data,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => expertsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-experts'] });
      toast.success('Expert supprimé avec succès');
    },
    onError: () => toast.error('Erreur lors de la suppression'),
  });

  const filtered = experts?.filter(e =>
    `${e.first_name} ${e.last_name}`.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a237e]">Experts</h1>
          <p className="text-gray-600 mt-1">Gestion de l'équipe d'experts</p>
        </div>
        <Button className="bg-[#1a237e] hover:bg-[#0d1245] text-white"><Plus className="w-4 h-4 mr-2" />Ajouter</Button>
      </motion.div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input placeholder="Rechercher..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10" />
      </div>

      {isLoading && <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 text-[#1a237e] animate-spin" /></div>}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(expert => (
          <motion.div key={expert.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                {expert.photo_url ? (
                  <img src={expert.photo_url} alt={`${expert.first_name} ${expert.last_name}`} className="w-12 h-12 rounded-full object-cover" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-[#1a237e]/10 flex items-center justify-center">
                    <User className="w-6 h-6 text-[#1a237e]" />
                  </div>
                )}
                <div>
                  <p className="font-bold text-gray-900">{expert.first_name} {expert.last_name}</p>
                  <p className="text-sm text-[#ff6f00]">{expert.title}</p>
                </div>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4 line-clamp-3">{expert.bio}</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1"><Edit2 className="w-3 h-3 mr-1" />Modifier</Button>
              <Button size="sm" variant="outline" className="text-red-500 hover:text-red-700" onClick={() => deleteMutation.mutate(expert.id)}>
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </motion.div>
        ))}
      </div>
      {!isLoading && filtered.length === 0 && <p className="text-center text-gray-500 py-8">Aucun expert trouvé.</p>}
    </div>
  );
}
