import { motion } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Trash2, CheckCircle, Loader2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { testimonialsAPI } from '@/services/api';
import type { Testimonial } from '@/types';

export default function AdminTestimonials() {
  const queryClient = useQueryClient();

  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ['admin-testimonials'],
    queryFn: async () => (await testimonialsAPI.getAll()).data,
  });

  const approveMutation = useMutation({
    mutationFn: (t: Testimonial) => testimonialsAPI.update(t.id, { is_approved: !t.is_approved }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-testimonials'] });
      toast.success('Statut mis à jour');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => testimonialsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-testimonials'] });
      toast.success('Témoignage supprimé');
    },
  });

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-[#1a237e]">Témoignages</h1>
        <p className="text-gray-600 mt-1">Modération des témoignages clients</p>
      </motion.div>

      {isLoading && <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 text-[#1a237e] animate-spin" /></div>}

      <div className="space-y-4">
        {testimonials?.map(t => (
          <motion.div key={t.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="font-bold text-gray-900">{t.author_name}</p>
                <p className="text-sm text-gray-500">{t.author_title} — {t.author_company}</p>
                <div className="flex mt-1">
                  {[...Array(t.rating)].map((_, i) => <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />)}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${t.is_approved ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                  {t.is_approved ? 'Approuvé' : 'En attente'}
                </span>
                {t.is_featured && <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">Mis en avant</span>}
              </div>
            </div>
            <p className="text-gray-600 text-sm italic mb-4">"{t.content}"</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => approveMutation.mutate(t)} className="text-green-600">
                <CheckCircle className="w-3 h-3 mr-1" />
                {t.is_approved ? 'Désapprouver' : 'Approuver'}
              </Button>
              <Button size="sm" variant="outline" className="text-red-500" onClick={() => deleteMutation.mutate(t.id)}>
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </motion.div>
        ))}
      </div>
      {!isLoading && !testimonials?.length && <p className="text-center text-gray-500 py-8">Aucun témoignage trouvé.</p>}
    </div>
  );
}
